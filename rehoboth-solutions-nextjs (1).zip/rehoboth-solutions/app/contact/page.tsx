import type { Metadata } from "next";
import { ContactForm } from "@/components/contact-form";
import { SectionHeading } from "@/components/section-heading";

export const metadata: Metadata = { alternates: { canonical: "/contact" }, title: "Contact", description: "Contact Rehoboth Solutions in India to discuss corporate solar, battery energy storage, investor introductions or global LFP battery sourcing." };

export default function ContactPage() {
  return (
    <>
      <section className="page-hero page-hero-simple">
        <div className="container">
          <span className="eyebrow">CONTACT REHOBOTH SOLUTIONS</span>
          <h1>Every good opportunity<br /><em>starts with a conversation.</em></h1>
          <p>Tell us what you are exploring. We’ll help identify the right next conversation.</p>
        </div>
      </section>
      <section className="section">
        <div className="container contact-layout">
          <div className="contact-aside">
            <SectionHeading eyebrow="GET IN TOUCH" title="Let’s understand your requirement." description="Whether you are exploring energy solutions, seeking project capital or discussing battery sourcing, we welcome a conversation." />
            <div className="contact-info-block"><span className="eyebrow">LOCATION</span><p>India</p></div>
            <div className="contact-info-block"><span className="eyebrow">EMAIL & PHONE</span><p>Official contact details to be added before launch.</p></div>
          </div>
          <ContactForm />
        </div>
      </section>
    </>
  );
}
