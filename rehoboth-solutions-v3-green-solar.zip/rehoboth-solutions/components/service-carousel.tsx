"use client";

import Link from "next/link";
import { useRef } from "react";
import { ArrowLeft, ArrowRight, ArrowUpRight, BatteryCharging, BriefcaseBusiness, Globe2, SunMedium } from "lucide-react";

const services = [
  { number: "01", title: "Solar energy solutions", description: "Explore practical solar procurement options through CAPEX, OPEX, RESCO and open-access models.", href: "/solar-energy", icon: SunMedium, label: "SOLAR" },
  { number: "02", title: "Battery energy storage", description: "Understand how BESS can support energy storage, peak demand management and renewable integration.", href: "/battery-storage", icon: BatteryCharging, label: "BESS" },
  { number: "03", title: "Investor advisory", description: "Connect projects and businesses with relevant investor networks and capital opportunities.", href: "/investor-advisory", icon: BriefcaseBusiness, label: "CAPITAL" },
  { number: "04", title: "Global LFP sourcing", description: "Develop international sourcing relationships for used and end-of-life LFP battery streams.", href: "/global-lfp-sourcing", icon: Globe2, label: "GLOBAL SOURCING" }
];

export function ServiceCarousel() {
  const track = useRef<HTMLDivElement>(null);
  const scroll = (direction: number) => track.current?.scrollBy({ left: direction * 370, behavior: "smooth" });
  return (
    <div className="service-carousel-wrap">
      <div className="service-carousel" ref={track} aria-label="Explore our four services">
        {services.map((service) => {
          const Icon = service.icon;
          return <Link className="service-card" href={service.href} key={service.href}>
            <div className="service-card-top"><span>{service.number} / {service.label}</span><Icon size={25} strokeWidth={1.5} /></div>
            <div><h3>{service.title}</h3><p>{service.description}</p></div>
            <span className="card-link">Explore service <ArrowUpRight size={16} /></span>
          </Link>;
        })}
      </div>
      <div className="service-carousel-controls">
        <span>Swipe or use arrows to explore</span>
        <div><button onClick={() => scroll(-1)} aria-label="Previous services"><ArrowLeft size={17} /></button><button onClick={() => scroll(1)} aria-label="Next services"><ArrowRight size={17} /></button></div>
      </div>
    </div>
  );
}
