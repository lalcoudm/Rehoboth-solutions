"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ArrowDownRight, ArrowRight, ArrowUpRight, ChevronLeft, ChevronRight } from "lucide-react";

const slides = [
  {
    eyebrow: "INDEPENDENT CONSULTING · INDIA",
    title: <>Building smarter<br /><em>business & energy</em><br />solutions.</>,
    description: "We help businesses explore opportunities, optimise resources and connect with the right energy, technology and financial partners.",
    image: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&fit=crop&w=2200&q=90",
    caption: "STRATEGY · CONNECTIONS · OPPORTUNITY"
  },
  {
    eyebrow: "CORPORATE SOLAR · BESS · OPEN ACCESS",
    title: <>A clearer path to<br /><em>smarter energy</em><br />decisions.</>,
    description: "Explore solar procurement and battery storage options aligned with your operations, energy profile and commercial priorities.",
    image: "https://images.unsplash.com/photo-1509391366360-2e959784a276?auto=format&fit=crop&w=2200&q=90",
    caption: "SOLAR · STORAGE · ENERGY TRANSITION"
  },
  {
    eyebrow: "CAPITAL · ADVISORY · GLOBAL SOURCING",
    title: <>Connecting ideas<br />with the right<br /><em>opportunities.</em></>,
    description: "From investor introductions to international LFP sourcing, we bring relevant stakeholders together to move opportunities forward.",
    image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=2200&q=90",
    caption: "BUSINESS ADVISORY · PARTNERSHIPS · SOURCING"
  }
];

export function HeroSlider() {
  const [active, setActive] = useState(0);
  const [paused, setPaused] = useState(false);
  useEffect(() => {
    if (paused || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const timer = window.setInterval(() => setActive((current) => (current + 1) % slides.length), 6500);
    return () => window.clearInterval(timer);
  }, [paused]);
  const slide = slides[active];
  const move = (direction: number) => setActive((current) => (current + direction + slides.length) % slides.length);

  return (
    <section className="home-hero" aria-roledescription="carousel" aria-label="Rehoboth Solutions highlights" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
      {slides.map((item, index) => <div key={item.eyebrow} className={`hero-image ${index === active ? "is-active" : ""}`} style={{ backgroundImage: `linear-gradient(90deg, rgba(13,34,42,.95) 0%, rgba(13,34,42,.78) 48%, rgba(13,34,42,.25) 100%), url("${item.image}")` }} aria-hidden="true" />)}
      <div className="container home-hero-content" key={active} aria-live="polite">
        <span className="eyebrow eyebrow-light">{slide.eyebrow}</span>
        <h1>{slide.title}</h1>
        <p>{slide.description}</p>
        <div className="hero-actions">
          <Link href="/solar-energy" className="button button-light">Explore our solutions <ArrowUpRight size={17} /></Link>
          <Link href="/about" className="text-link text-link-light">Discover Rehoboth <ArrowDownRight size={16} /></Link>
        </div>
        <div className="hero-caption"><span className="hero-caption-line" />{slide.caption}</div>
      </div>
      <div className="hero-controls">
        <div className="hero-pagination" aria-label="Choose slide">
          {slides.map((item, index) => <button key={item.eyebrow} className={index === active ? "active" : ""} onClick={() => setActive(index)} aria-label={`Go to slide ${index + 1}`} aria-current={index === active ? "true" : undefined}><span /></button>)}
        </div>
        <span className="hero-count">0{active + 1} <i>/</i> 0{slides.length}</span>
        <button className="hero-arrow" onClick={() => move(-1)} aria-label="Previous slide"><ChevronLeft size={19} /></button>
        <button className="hero-arrow" onClick={() => move(1)} aria-label="Next slide"><ChevronRight size={19} /></button>
      </div>
      <div className="hero-side-note">REHOBOTH SOLUTIONS / INDIA</div>
      <Link href="/contact" className="hero-quick-link">Discuss an opportunity <ArrowRight size={14} /></Link>
    </section>
  );
}
