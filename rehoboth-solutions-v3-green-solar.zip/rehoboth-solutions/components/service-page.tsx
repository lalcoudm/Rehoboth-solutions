import Link from "next/link";
import type { ReactNode } from "react";
import { ArrowRight, ArrowUpRight, Check } from "lucide-react";
import { SectionHeading } from "@/components/section-heading";

type ServicePageProps = {
  eyebrow: string;
  title: ReactNode;
  intro: string;
  image: string;
  imageAlt: string;
  benefits: string[];
  approach: { title: string; description: string }[];
  audience: string[];
  note?: string;
};

export function ServicePage({ eyebrow, title, intro, image, imageAlt, benefits, approach, audience, note }: ServicePageProps) {
  const serviceSchema = {
    "@context": "https://schema.org",
    "@type": "Service",
    name: eyebrow.replace(/\s*\/\s*\d+$/, ""),
    serviceType: eyebrow,
    description: intro,
    provider: { "@type": "Organization", name: "Rehoboth Solutions" },
    areaServed: { "@type": "Country", name: "India" }
  };
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceSchema) }} />
      <section className="service-hero">
        <div className="container service-hero-grid">
          <div className="service-hero-copy">
            <span className="eyebrow">{eyebrow}</span>
            <h1>{title}</h1>
            <p>{intro}</p>
            <Link href="/contact" className="button button-dark">Discuss an opportunity <ArrowUpRight size={17} /></Link>
          </div>
          <div className="service-hero-image" style={{ backgroundImage: `url(${image})` }} role="img" aria-label={imageAlt} />
        </div>
      </section>

      <section className="section">
        <div className="container two-column">
          <SectionHeading eyebrow="WHAT WE HELP WITH" title="A considered approach to better business outcomes." />
          <div className="benefit-list">
            {benefits.map((item) => (
              <div className="benefit-item" key={item}><span className="check-icon"><Check size={15} /></span><span>{item}</span></div>
            ))}
          </div>
        </div>
      </section>

      <section className="section section-muted">
        <div className="container">
          <SectionHeading eyebrow="HOW WE WORK" title="From understanding to the right connection." description="We bring structure to the early stages of an opportunity, helping clients understand their options and engage with relevant specialist partners." />
          <div className="approach-grid">
            {approach.map((item, index) => (
              <article className="approach-card" key={item.title}>
                <span className="approach-number">0{index + 1}</span>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container audience-layout">
          <div>
            <SectionHeading eyebrow="WHO WE WORK WITH" title="Working across business and industry." />
            {note && <p className="fine-print">{note}</p>}
          </div>
          <div className="audience-tags">{audience.map((item) => <span key={item}>{item}</span>)}</div>
        </div>
      </section>

      <section className="cta-band">
        <div className="container cta-band-inner">
          <div><span className="eyebrow eyebrow-light">LET’S EXPLORE WHAT’S POSSIBLE</span><h2>Start a conversation with Rehoboth Solutions.</h2></div>
          <Link href="/contact" className="button button-light">Talk to our team <ArrowRight size={17} /></Link>
        </div>
      </section>
    </>
  );
}
