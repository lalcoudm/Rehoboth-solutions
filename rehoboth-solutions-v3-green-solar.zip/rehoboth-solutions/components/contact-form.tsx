"use client";

import { FormEvent, useState } from "react";
import { ArrowUpRight, CheckCircle2 } from "lucide-react";

export function ContactForm() {
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");
  const [message, setMessage] = useState("");

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("sending");
    setMessage("");
    const form = event.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to send your enquiry.");
      setStatus("success");
      setMessage("Thank you. Your enquiry has been received.");
      form.reset();
    } catch (error) {
      setStatus("error");
      setMessage(error instanceof Error ? error.message : "Something went wrong. Please try again.");
    }
  }

  return (
    <form className="contact-form" onSubmit={handleSubmit}>
      <div className="form-heading"><span className="eyebrow">ENQUIRY FORM</span><h2>How can we help?</h2></div>
      <div className="form-row">
        <label>Full name<input name="name" placeholder="Your name" required /></label>
        <label>Company<input name="company" placeholder="Company name" /></label>
      </div>
      <div className="form-row">
        <label>Work email<input name="email" type="email" placeholder="name@company.com" required /></label>
        <label>Phone<input name="phone" type="tel" placeholder="+91" /></label>
      </div>
      <label>I'm interested in
        <select name="interest" defaultValue="" required>
          <option value="" disabled>Select a service</option>
          <option>Solar energy solutions</option>
          <option>Battery energy storage (BESS)</option>
          <option>Investor advisory</option>
          <option>Global LFP sourcing</option>
          <option>General business enquiry</option>
        </select>
      </label>
      <label>Tell us a little about your requirement<textarea name="message" rows={5} placeholder="Share a few details about the opportunity..." required /></label>
      <button className="button button-dark form-submit" type="submit" disabled={status === "sending"}>
        {status === "sending" ? "Sending..." : "Submit enquiry"} <ArrowUpRight size={17} />
      </button>
      {message && <p className={`form-message ${status}`} role="status">{status === "success" && <CheckCircle2 size={17} />}{message}</p>}
      <p className="form-privacy">Your details will be used only to respond to this enquiry. Add the company’s final privacy policy before launch.</p>
    </form>
  );
}
