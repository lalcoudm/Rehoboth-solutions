"use client";

import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { Brand } from "@/components/brand";

const serviceLinks = [
  ["Solar energy", "/solar-energy"],
  ["Battery storage", "/battery-storage"],
  ["Investor advisory", "/investor-advisory"],
  ["Global LFP sourcing", "/global-lfp-sourcing"]
];

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="container footer-top">
        <div className="footer-brand-block">
          <Brand light />
          <p>Building smarter business and energy solutions through experience, insight and meaningful partnerships.</p>
        </div>
        <div className="footer-column">
          <span className="footer-heading">EXPLORE</span>
          <Link href="/about">About Rehoboth</Link>
          <Link href="/contact">Contact</Link>
        </div>
        <div className="footer-column">
          <span className="footer-heading">SOLUTIONS</span>
          {serviceLinks.map(([label, href]) => <Link href={href} key={href}>{label}</Link>)}
        </div>
        <div className="footer-contact">
          <span className="footer-heading">LET’S CONNECT</span>
          <p>Have a business or energy challenge to explore?</p>
          <Link className="footer-link" href="/contact">Start a conversation <ArrowUpRight size={15} /></Link>
          <span className="footer-placeholder">Add official email and phone before launch.</span>
        </div>
      </div>
      <div className="container footer-bottom">
        <span>© {new Date().getFullYear()} Rehoboth Solutions. All rights reserved.</span>
        <span>India · Independent Consulting</span>
      </div>
    </footer>
  );
}
