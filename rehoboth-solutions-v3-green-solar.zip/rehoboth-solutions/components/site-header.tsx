"use client";

import Link from "next/link";
import { useState } from "react";
import { ArrowUpRight, ChevronDown, Menu, X } from "lucide-react";
import { Brand } from "@/components/brand";

const services = [
  { href: "/solar-energy", label: "Solar energy solutions", note: "CAPEX · OPEX · Open access" },
  { href: "/battery-storage", label: "Battery energy storage", note: "BESS · Energy optimisation" },
  { href: "/investor-advisory", label: "Investor advisory", note: "Projects · Capital facilitation" },
  { href: "/global-lfp-sourcing", label: "Global LFP sourcing", note: "Battery supply · Recycling" }
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [solutionsOpen, setSolutionsOpen] = useState(false);

  return (
    <header className="site-header">
      <div className="container header-inner">
        <div onClick={() => setOpen(false)}><Brand /></div>

        <nav className="desktop-nav" aria-label="Main navigation">
          <Link href="/">Home</Link>
          <Link href="/about">About</Link>
          <div className="nav-dropdown">
            <button className="nav-dropdown-trigger" onClick={() => setSolutionsOpen(!solutionsOpen)} aria-expanded={solutionsOpen}>
              Solutions <ChevronDown size={14} />
            </button>
            {solutionsOpen && (
              <div className="dropdown-panel">
                {services.map((service) => (
                  <Link key={service.href} href={service.href} onClick={() => setSolutionsOpen(false)}>
                    <strong>{service.label}</strong>
                    <span>{service.note}</span>
                  </Link>
                ))}
              </div>
            )}
          </div>
          <Link href="/contact">Contact</Link>
        </nav>

        <Link href="/contact" className="header-cta">Start a conversation <ArrowUpRight size={15} /></Link>
        <button className="mobile-menu-button" aria-label={open ? "Close menu" : "Open menu"} onClick={() => setOpen(!open)}>
          {open ? <X /> : <Menu />}
        </button>
      </div>

      {open && (
        <div className="mobile-nav">
          <Link href="/" onClick={() => setOpen(false)}>Home</Link>
          <Link href="/about" onClick={() => setOpen(false)}>About</Link>
          <span className="mobile-nav-label">SOLUTIONS</span>
          {services.map((service) => (
            <Link key={service.href} href={service.href} onClick={() => setOpen(false)}>{service.label}</Link>
          ))}
          <Link href="/contact" onClick={() => setOpen(false)}>Contact</Link>
        </div>
      )}
    </header>
  );
}
