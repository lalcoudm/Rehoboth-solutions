import Link from "next/link";

export function Brand({ light = false }: { light?: boolean }) {
  return (
    <Link href="/" className={`brand ${light ? "brand-light" : ""}`} aria-label="Rehoboth Solutions home">
      <svg className="brand-symbol" viewBox="0 0 48 48" role="img" aria-label="Rehoboth Solutions symbol">
        <path d="M8 39V9h16.5c8.2 0 13.5 4.3 13.5 11.1 0 5.1-3.1 8.6-8.4 10l9.2 8.9" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="square" />
        <path d="M17 17h8c2.4 0 4 1.1 4 3.1s-1.6 3.2-4 3.2h-8" fill="none" stroke="#48a77d" strokeWidth="2.6" strokeLinecap="square" />
        <path d="M8 39h10" stroke="#48a77d" strokeWidth="2.6" />
      </svg>
      <span className="brand-copy"><strong>REHOBOTH</strong><small>S O L U T I O N S</small></span>
    </Link>
  );
}
