import type { Metadata } from "next";
import { ServicePage } from "@/components/service-page";

export const metadata: Metadata = { alternates: { canonical: "/solar-energy" }, title: "Solar Energy Solutions", description: "Corporate and industrial solar energy solutions in India. Explore CAPEX, OPEX, RESCO and eligible open-access procurement models." };

export default function SolarPage() {
  return <ServicePage
    eyebrow="ENERGY SOLUTIONS / 01"
    title={<>Make solar work<br /><em>for your business.</em></>}
    intro="Explore practical ways to access renewable electricity, manage energy expenditure and evaluate solar opportunities—without assuming every business needs the same model."
    image="https://images.unsplash.com/photo-1509391366360-2e959784a276?auto=format&fit=crop&w=1800&q=85"
    imageAlt="Solar panels under a clear sky"
    benefits={[
      "Evaluate on-site rooftop and ground-mounted solar opportunities.",
      "Explore CAPEX and OPEX / RESCO models based on business priorities.",
      "Assess third-party solar procurement through applicable open-access structures.",
      "Connect with relevant solar developers, power producers and EPC partners."
    ]}
    approach={[
      { title: "Understand consumption", description: "Review electricity usage, tariff structure, location and broad business requirements." },
      { title: "Explore the model", description: "Compare CAPEX, OPEX, RESCO and eligible open-access pathways." },
      { title: "Connect the partners", description: "Facilitate discussions with suitable developers and energy providers." },
      { title: "Progress evaluation", description: "Coordinate technical, commercial and regulatory assessment with specialist teams." }
    ]}
    audience={["Manufacturing facilities", "Automotive & engineering", "Textile & food processing", "Pharmaceuticals", "Warehousing & logistics", "Commercial campuses"]}
    note="Project feasibility, savings and eligibility depend on site conditions, tariff structures, applicable state regulations and the final commercial agreement."
  />;
}
