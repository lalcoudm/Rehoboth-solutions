import type { Metadata } from "next";
import { ServicePage } from "@/components/service-page";

export const metadata: Metadata = { alternates: { canonical: "/battery-storage" }, title: "Battery Energy Storage", description: "Explore battery energy storage systems (BESS) in India for peak demand management, solar integration, tariff optimisation and power resilience." };

export default function BatteryPage() {
  return <ServicePage
    eyebrow="ENERGY SOLUTIONS / 02"
    title={<>Store energy.<br /><em>Unlock flexibility.</em></>}
    intro="Battery Energy Storage Systems can help businesses manage when they use electricity, support renewable integration and improve power resilience. Rehoboth helps organisations explore where storage may make commercial sense."
    image="https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&fit=crop&w=1800&q=85"
    imageAlt="Electricity transmission infrastructure at sunset"
    benefits={[
      "Explore peak demand management and tariff optimisation opportunities.",
      "Evaluate storage alongside rooftop or open-access solar procurement.",
      "Consider backup support for selected critical loads and operations.",
      "Connect with BESS technology providers, integrators and project developers."
    ]}
    approach={[
      { title: "Understand the load", description: "Review electricity bills, demand patterns, operating hours and critical loads." },
      { title: "Identify use cases", description: "Explore peak management, solar shifting, backup and other relevant applications." },
      { title: "Engage specialists", description: "Connect with BESS providers for system sizing, safety and integration assessment." },
      { title: "Review economics", description: "Evaluate project cost, operating assumptions, tariff benefits and lifecycle economics." }
    ]}
    audience={["Energy-intensive manufacturers", "Data centres", "Commercial buildings", "Industrial parks", "Solar asset owners", "Critical infrastructure"]}
    note="BESS performance and financial returns depend on load profile, tariff, system configuration, battery chemistry, operating strategy, degradation and project costs."
  />;
}
