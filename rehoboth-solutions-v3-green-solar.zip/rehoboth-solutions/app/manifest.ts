import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return { name: "Rehoboth Solutions", short_name: "Rehoboth", description: "Building smarter business and energy solutions.", start_url: "/", display: "standalone", background_color: "#fbfcfa", theme_color: "#142c35", icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml" }] };
}
