import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { SectionHeading } from "@/components/section-heading";

export const metadata: Metadata = { alternates: { canonical: "/about" }, title: "About Us", description: "Independent consulting in India led by founder Daniel Saravanan, connecting business needs with energy, capital and global sourcing opportunities." };

export default function AboutPage() {
  return (
    <>
      <section className="page-hero page-hero-simple">
        <div className="container">
          <span className="eyebrow">ABOUT REHOBOTH SOLUTIONS</span>
          <h1>Experience with a<br /><em>forward-looking mindset.</em></h1>
          <p>An independent consulting firm connecting business needs with practical energy, financial and sourcing opportunities.</p>
        </div>
      </section>
      <section className="section">
        <div className="container about-story-grid">
          <div><span className="eyebrow">OUR APPROACH</span><span className="about-big-number">20<span>+</span></span><span className="about-number-label">YEARS OF INDUSTRY & CONSULTING EXPERIENCE*</span></div>
          <div className="about-story-copy">
            <h2>We believe progress happens when the right expertise meets the right opportunity.</h2>
            <p>Rehoboth Solutions works with businesses, project owners, investors and specialist solution providers to explore opportunities across energy, business advisory and global sourcing.</p>
            <p>Our role is to understand the requirement, identify relevant options, facilitate meaningful connections and help move discussions towards informed next steps.</p>
            <p className="fine-print">*Founder experience as provided by the company. Final published profile should include supporting career details.</p>
          </div>
        </div>
      </section>
      <section className="section section-muted">
        <div className="container">
          <SectionHeading eyebrow="LEADERSHIP" title="A consulting approach shaped by experience." />
          <div className="founder-card">
            <div className="founder-monogram">DS<span>.</span></div>
            <div className="founder-details">
              <span className="eyebrow">FOUNDER</span>
              <h2>Daniel Saravanan</h2>
              <p>Founder, Rehoboth Solutions</p>
              <p className="founder-bio">With over 20 years of industry and consulting experience, Daniel leads Rehoboth Solutions with a focus on practical business understanding, strategic relationships and opportunity development.</p>
              <span className="fine-print">Founder photograph and detailed professional biography to be added.</span>
            </div>
          </div>
        </div>
      </section>
      <section className="cta-band"><div className="container cta-band-inner"><div><span className="eyebrow eyebrow-light">WORK WITH REHOBOTH</span><h2>Let’s explore what’s possible.</h2></div><Link href="/contact" className="button button-light">Get in touch <ArrowUpRight size={16} /></Link></div></section>
    </>
  );
}
