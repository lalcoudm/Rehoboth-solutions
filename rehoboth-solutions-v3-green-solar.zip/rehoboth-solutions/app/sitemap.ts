import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  const configuredUrl = process.env.NEXT_PUBLIC_SITE_URL;
  if (!configuredUrl) return [];
  const base = configuredUrl.replace(/\/$/, "");
  const routes = ["", "/about", "/solar-energy", "/battery-storage", "/investor-advisory", "/global-lfp-sourcing", "/contact"];
  return routes.map((route) => ({ url: `${base}${route}`, changeFrequency: route === "" ? "weekly" : "monthly", priority: route === "" ? 1 : route === "/contact" ? 0.8 : 0.7 }));
}
