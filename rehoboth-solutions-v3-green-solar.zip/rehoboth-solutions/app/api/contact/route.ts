import { NextResponse } from "next/server";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, email, interest, message } = body ?? {};

    if (!name || !email || !interest || !message) {
      return NextResponse.json({ error: "Please complete all required fields." }, { status: 400 });
    }

    const apiKey = process.env.RESEND_API_KEY;
    const to = process.env.CONTACT_TO_EMAIL;
    const from = process.env.CONTACT_FROM_EMAIL;

    if (!apiKey || !to || !from) {
      return NextResponse.json(
        { error: "The enquiry form is not connected yet. Please add the email settings or contact the company directly." },
        { status: 503 }
      );
    }

    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from,
        to: [to],
        reply_to: email,
        subject: `Website enquiry: ${interest}`,
        text: [
          `Name: ${name}`,
          `Company: ${body.company || "Not provided"}`,
          `Email: ${email}`,
          `Phone: ${body.phone || "Not provided"}`,
          `Interest: ${interest}`,
          "",
          "Message:",
          message
        ].join("\n")
      })
    });

    if (!response.ok) {
      return NextResponse.json({ error: "We couldn't send your enquiry right now. Please try again later." }, { status: 502 });
    }

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Invalid request. Please try again." }, { status: 400 });
  }
}
