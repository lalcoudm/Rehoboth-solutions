import type { Metadata } from "next";
import { ServicePage } from "@/components/service-page";

export const metadata: Metadata = { alternates: { canonical: "/global-lfp-sourcing" }, title: "Global LFP Sourcing", description: "Global LFP battery sourcing support: supplier mapping and initial qualification of used and end-of-life lithium iron phosphate battery streams." };

export default function LfpPage() {
  return <ServicePage
    eyebrow="GLOBAL SOURCING / 04"
    title={<>Building pathways<br /><em>for battery resources.</em></>}
    intro="We support the identification and initial engagement of international suppliers, aggregators and battery lifecycle partners for used and end-of-life lithium iron phosphate (LFP) battery streams."
    image="https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&w=1800&q=85"
    imageAlt="Electric vehicle charging infrastructure"
    benefits={[
      "Map potential battery holders, fleet operators, recyclers and aggregators.",
      "Research supplier organisations and relevant commercial stakeholders.",
      "Open initial discussions and understand the broad supply opportunity.",
      "Coordinate qualified opportunities with the designated recycling and technical teams."
    ]}
    approach={[
      { title: "Map the supply landscape", description: "Research relevant organisations across the United States, Australia, Norway, Finland and selected African markets." },
      { title: "Identify stakeholders", description: "Find asset owners, fleet operators, energy storage operators, recyclers and potential resellers." },
      { title: "Open conversations", description: "Establish contact and understand the supplier's role, material stream and willingness to engage." },
      { title: "Qualify and hand over", description: "Capture available chemistry, condition and volume information before referral for technical and regulatory review." }
    ]}
    audience={["EV fleet operators", "Battery recyclers", "Energy storage operators", "Battery aggregators", "Automotive dismantlers", "Industrial battery holders"]}
    note="All sourcing opportunities remain subject to chemistry verification, ownership and traceability checks, technical acceptance and applicable cross-border waste and battery regulations. Import and regulatory execution is handled by the appointed specialist partner."
  />;
}
