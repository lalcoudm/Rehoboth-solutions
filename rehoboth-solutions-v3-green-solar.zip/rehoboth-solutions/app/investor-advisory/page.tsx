import type { Metadata } from "next";
import { ServicePage } from "@/components/service-page";

export const metadata: Metadata = { alternates: { canonical: "/investor-advisory" }, title: "Investor Advisory", description: "Investor advisory and project-investor facilitation in India, supporting project readiness, investor discovery and relevant business introductions." };

export default function InvestorPage() {
  return <ServicePage
    eyebrow="BUSINESS ADVISORY / 03"
    title={<>Connecting projects<br /><em>with capital opportunities.</em></>}
    intro="We help project owners and businesses organise their funding proposition, identify relevant investor profiles and facilitate informed introductions with potential capital partners."
    image="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1800&q=85"
    imageAlt="Modern corporate buildings"
    benefits={[
      "Understand project stage, funding requirement and intended use of funds.",
      "Identify potential investor categories aligned to sector and investment profile.",
      "Organise high-level project information for initial investor conversations.",
      "Facilitate introductions and coordinate follow-up discussions."
    ]}
    approach={[
      { title: "Understand the project", description: "Review business model, stage, funding requirement, use of funds and readiness." },
      { title: "Map investor fit", description: "Research investor categories, sector interests, ticket sizes and investment mandates." },
      { title: "Facilitate introductions", description: "Coordinate relevant conversations and share approved, appropriate project information." },
      { title: "Support next steps", description: "Help organise discussions between project owners, investors and their professional advisers." }
    ]}
    audience={["Technology ventures", "Manufacturing projects", "Growth-stage businesses", "Infrastructure projects", "Expansion initiatives", "Selected turnaround situations"]}
    note="Rehoboth Solutions facilitates business introductions and advisory coordination. It does not represent itself as an investment fund, guarantee funding or provide regulated investment advice. Any transaction is subject to investor due diligence and appropriate legal and financial advice."
  />;
}
