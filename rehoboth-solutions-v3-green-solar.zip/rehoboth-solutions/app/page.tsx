import Link from "next/link";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { HeroSlider } from "@/components/hero-slider";
import type { Metadata } from "next";
import { SectionHeading } from "@/components/section-heading";
import { ServiceCarousel } from "@/components/service-carousel";

export const metadata: Metadata = {
  alternates: { canonical: "/" },
  title: "Corporate Solar, BESS & Business Advisory in India",
  description: "Explore corporate solar CAPEX, OPEX and open-access options, battery energy storage, investor advisory and global LFP sourcing with Rehoboth Solutions.",
  keywords: ["energy consulting India", "corporate solar India", "BESS India", "investor advisory", "LFP battery sourcing"]
};

export default function HomePage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
        "@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [
          { "@type": "Question", "name": "What solar procurement models can a business explore in India?", "acceptedAnswer": { "@type": "Answer", "text": "Depending on site conditions, state regulations, consumption profile and commercial terms, businesses may explore CAPEX solar, OPEX or RESCO arrangements and eligible third-party open-access procurement." } },
          { "@type": "Question", "name": "How can battery energy storage help an industrial business?", "acceptedAnswer": { "@type": "Answer", "text": "A Battery Energy Storage System may support peak demand management, solar energy shifting, selected critical-load resilience and energy flexibility. Suitability depends on load data, tariff, design and lifecycle economics." } },
          { "@type": "Question", "name": "Does Rehoboth Solutions directly provide or guarantee project funding?", "acceptedAnswer": { "@type": "Answer", "text": "No. Rehoboth Solutions supports project readiness, investor discovery and introductions. Funding decisions remain with independent investors and are not guaranteed." } },
          { "@type": "Question", "name": "Does Rehoboth Solutions import or certify used LFP batteries?", "acceptedAnswer": { "@type": "Answer", "text": "The firm supports initial supplier mapping and introductions. Technical acceptance and cross-border regulatory requirements must be verified by specialist partners." } }
        ]
      }) }} />
      <HeroSlider />

      <section className="intro-section section">
        <div className="container intro-grid">
          <div className="intro-label"><span className="eyebrow">WHO WE ARE</span><span className="intro-index">01 / 04</span></div>
          <div className="intro-copy">
            <h2>Good decisions begin with the right perspective.</h2>
            <p>Rehoboth Solutions is an independent consulting firm working at the intersection of energy, business advisory and strategic sourcing. We bring together industry understanding and a network-led approach to help organisations evaluate opportunities and move conversations forward.</p>
            <Link href="/about" className="text-link">More about Rehoboth <ArrowUpRight size={16} /></Link>
          </div>
        </div>
      </section>

      <section className="section solutions-section">
        <div className="container">
          <div className="solutions-heading-row">
            <SectionHeading eyebrow="WHAT WE DO" title="Four capabilities. One connected approach." description="From energy cost optimisation to capital and sourcing opportunities, we help businesses find a clearer path forward." />
            <span className="section-side-note">OUR SOLUTIONS<br />02 / 04</span>
          </div>
          <ServiceCarousel />
        </div>
      </section>

      <section className="feature-section">
        <div className="feature-photo" />
        <div className="feature-copy">
          <span className="eyebrow eyebrow-light">OUR PERSPECTIVE</span>
          <h2>Experience matters.<br /><em>Connections make it work.</em></h2>
          <p>Led by founder Daniel Saravanan, Rehoboth Solutions draws on over 20 years of industry and consulting experience to bring businesses, solution providers and opportunities together.</p>
          <Link href="/about" className="text-link text-link-light">Meet the founder <ArrowUpRight size={16} /></Link>
        </div>
      </section>

      <section className="section approach-section">
        <div className="container">
          <SectionHeading eyebrow="HOW WE ENGAGE" title="A clear process. A practical mindset." description="Every engagement starts by understanding the business context and identifying the right next step." />
          <div className="process-grid">
            {[
              ["01", "Understand", "We listen to the business requirement, context and desired outcome."],
              ["02", "Evaluate", "We help assess available options, suitability and potential partners."],
              ["03", "Connect", "We facilitate relevant conversations with solution providers and stakeholders."],
              ["04", "Progress", "We coordinate the next steps with the appropriate specialist teams."]
            ].map(([number, title, body]) => <article className="process-item" key={number}><span>{number}</span><h3>{title}</h3><p>{body}</p></article>)}
          </div>
        </div>
      </section>

      <section className="section faq-section">
        <div className="container faq-layout">
          <div><span className="eyebrow">COMMON QUESTIONS</span><h2>Clarity before the next step.</h2><p>Some of the questions businesses ask when exploring energy, capital and sourcing opportunities.</p></div>
          <div className="faq-list">
            <details><summary>What solar procurement models can a business explore in India?</summary><p>Depending on the site, state regulations, consumption profile and commercial terms, businesses may explore CAPEX rooftop or ground-mounted solar, OPEX/RESCO arrangements and eligible third-party open-access procurement.</p></details>
            <details><summary>How can battery energy storage help an industrial business?</summary><p>A Battery Energy Storage System may support peak demand management, solar energy shifting, selected critical-load resilience and energy flexibility. The right use case depends on interval load data, tariff structure, system design and lifecycle economics.</p></details>
            <details><summary>Does Rehoboth Solutions directly provide or guarantee project funding?</summary><p>No. Rehoboth Solutions supports project readiness, investor discovery and relevant introductions. Funding decisions remain with independent investors and are subject to their due diligence; funding or investment outcomes are not guaranteed.</p></details>
            <details><summary>Does Rehoboth Solutions import or certify used LFP batteries?</summary><p>The firm supports initial global supplier mapping and commercial introductions. Battery chemistry, condition, traceability, technical acceptance and cross-border regulatory requirements must be verified by the appointed specialist partners.</p></details>
          </div>
        </div>
      </section>

      <section className="cta-band">
        <div className="container cta-band-inner">
          <div><span className="eyebrow eyebrow-light">HAVE AN OPPORTUNITY TO DISCUSS?</span><h2>Let’s find the right way forward.</h2></div>
          <Link href="/contact" className="button button-light">Start a conversation <ArrowRight size={17} /></Link>
        </div>
      </section>
    </>
  );
}
