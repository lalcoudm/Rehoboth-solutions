import type { Metadata } from "next";
import "./globals.css";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL;
const description = "Rehoboth Solutions is an independent India-focused consulting firm helping organisations evaluate corporate solar, battery energy storage, investor introductions and global LFP battery sourcing opportunities.";

export const metadata: Metadata = {
  title: {
    default: "Rehoboth Solutions | Energy & Business Advisory in India",
    template: "%s | Rehoboth Solutions"
  },
  description,
  ...(siteUrl ? { metadataBase: new URL(siteUrl) } : {}),
  applicationName: "Rehoboth Solutions",
  keywords: [
    "corporate solar solutions India", "industrial solar consulting", "solar CAPEX OPEX RESCO",
    "open access solar India", "battery energy storage systems India", "BESS consulting",
    "investor advisory India", "LFP battery sourcing", "energy consulting India"
  ],
  openGraph: {
    title: "Rehoboth Solutions | Building Smarter Business & Energy Solutions",
    description,
    type: "website",
    siteName: "Rehoboth Solutions",
    locale: "en_IN"
  },
  twitter: {
    card: "summary_large_image",
    title: "Rehoboth Solutions | Energy & Business Advisory",
    description
  },
  robots: { index: true, follow: true, googleBot: { index: true, follow: true, "max-image-preview": "large", "max-snippet": -1, "max-video-preview": -1 } }
};

const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "Rehoboth Solutions",
  description,
  ...(siteUrl ? { url: siteUrl } : {}),
  areaServed: { "@type": "Country", name: "India" },
  founder: { "@type": "Person", name: "Daniel Saravanan", jobTitle: "Founder" },
  knowsAbout: ["Solar energy procurement", "Battery energy storage systems", "Investor and project advisory", "Lithium iron phosphate battery sourcing"]
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en-IN">
      <body>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }} />
        <SiteHeader />
        <main>{children}</main>
        <SiteFooter />
      </body>
    </html>
  );
}
