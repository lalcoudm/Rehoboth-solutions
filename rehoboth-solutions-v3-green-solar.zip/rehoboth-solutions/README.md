# Rehoboth Solutions website

A responsive Next.js App Router website for Rehoboth Solutions.

## Included pages

- `/` — Home
- `/about` — About and founder profile
- `/solar-energy` — Solar CAPEX, OPEX, RESCO and open-access advisory
- `/battery-storage` — Battery Energy Storage Systems (BESS)
- `/investor-advisory` — Investor discovery and project facilitation
- `/global-lfp-sourcing` — International LFP sourcing
- `/contact` — Contact enquiry form

## Requirements

- Node.js 20.9 or newer
- npm

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Production build

```bash
npm run build
npm start
```

## Contact form setup

The contact form API is wired to Resend. Copy `.env.example` to `.env.local` and configure:

```env
RESEND_API_KEY=your_resend_api_key
CONTACT_TO_EMAIL=the_company_inbox@example.com
CONTACT_FROM_EMAIL=verified_sender@yourdomain.com
```

Without these values, the form intentionally returns a setup message instead of pretending an enquiry was delivered.

## Before launch

1. Set `NEXT_PUBLIC_SITE_URL` in `.env.local` to the verified production domain (include https://). The sitemap and canonical metadata use this value.
2. Add official email, phone, address and social profile links.
3. Add Daniel Saravanan's approved photograph and a verified professional biography.
4. Confirm the legal company name, registered address and business details.
5. Review service descriptions, especially investment facilitation and cross-border battery sourcing, with the company's legal/compliance advisers.
6. Add privacy policy and terms pages.
7. Replace stock photography with licensed company/project imagery where available.
8. Configure analytics, Search Console, sitemap submission and production hosting.

## Notes

- The website describes Rehoboth Solutions as a consulting and facilitation firm. It does not claim to own solar assets, manufacture BESS equipment, act as an investment fund or directly execute cross-border battery imports.
- Commercial savings, regulatory eligibility, technical feasibility and investor funding are not guaranteed.
- The current design uses remote Unsplash image URLs for visual placeholders. Replace or locally host appropriately licensed images before production.

## Search visibility and AI discovery

The project includes page-level metadata, Open Graph/Twitter metadata, Organization structured data, a generated sitemap and robots rules, an SVG brand icon, and `public/llms.txt` as a concise machine-readable overview. Before launch, set the verified `NEXT_PUBLIC_SITE_URL`, add real contact details and social profiles, connect Google Search Console and Bing Webmaster Tools, and publish original case studies and FAQs. These foundations improve crawlability and entity clarity but cannot guarantee rankings or AI citations.

## Homepage carousel

The homepage hero has three responsive slides with autoplay, pause-on-hover, manual arrows and pagination controls. It respects reduced-motion preferences through the site-wide CSS.


## Version 2 visual/content refinement

- Refined palette: midnight navy, deep energy green, warm ivory, muted sage and restrained brass accent.
- More editorial/cinematic visual styling and section contrast.
- Added a homepage business-energy context section.
- Contact page contains editable phone/email placeholders.
- Research/content additions are deliberately framed as general context rather than claims of guaranteed outcomes.

Before production:
- Replace contact placeholders.
- Confirm founder biography and credentials.
- Confirm domain and metadata base.
- Review image licensing and replace placeholders with approved images.
- Run `npm install`, `npm run build`, and functional testing.


## Version 3 colour direction

- Primary identity: Forest Energy Green `#174C3A`
- Secondary: Natural Green `#78A68A`
- Solar accent: Solar Gold `#F2B544`
- Deep supporting colour: Deep Blue `#193442`
- Light background: Warm Ivory `#F7F5EF`
- Secondary background: Soft Green Grey `#DCE7DF`

Green is the dominant brand colour. Solar gold is a restrained accent for calls to action, highlights, icon details and visual cues. Deep blue is retained for corporate depth and contrast.
